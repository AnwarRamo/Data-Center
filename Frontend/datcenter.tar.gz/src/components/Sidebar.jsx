import { Plus, Minus, User } from "lucide-react";

export default function Sidebar({ members, addMember, removeMember }) {
  return (
    <div className="w-[250px] bg-[#DCFFF7] p-6 rounded-l-3xl flex flex-col items-end shadow-[0_4px_15px_rgba(0,0,0,0.05)]">
      <div className="flex items-center justify-end w-full gap-2 mb-8">
        <User className="w-5 h-5 text-[#1A1F33]" />
        <h2 className="text-lg font-semibold text-[#1A1F33]">أسم رب الأسرة </h2>
      </div>
      <div className="space-y-4 w-full">
        {members.map((name, i) => (
          <button
            key={i}
            className="bg-white w-[172px] h-[44px] flex-shrink-0 rounded-3xl text-sm font-medium text-center text-[#1A1F33] shadow-[inset_5px_6px_8px_0px_rgba(0,0,0,0.25)] hover:bg-gray-50 flex items-center justify-center mx-auto"
          >
            {name}
          </button>
        ))}
        <button
          onClick={addMember}
          className="flex items-center justify-start gap-3 bg-white w-[172px] h-[44px] flex-shrink-0 rounded-3xl text-sm font-medium text-[#1A1F33] shadow-[inset_5px_6px_8px_0px_rgba(0,0,0,0.25)] hover:bg-gray-50 mx-auto"
        >
          <Plus className="w-4 h-4 ml-8" />
          إضافة عميل
        </button>
        <button
          onClick={removeMember}
          className="flex items-center justify-start gap-3 bg-white w-[172px] h-[44px] flex-shrink-0 rounded-3xl text-sm font-medium text-[#1A1F33] shadow-[inset_5px_6px_8px_0px_rgba(0,0,0,0.25)] hover:bg-gray-50 mx-auto"
          disabled={members.length === 0}
        >
          <Minus className="w-4 h-4 ml-8" />
          حذف عميل
        </button>
      </div>
    </div>
  );
}