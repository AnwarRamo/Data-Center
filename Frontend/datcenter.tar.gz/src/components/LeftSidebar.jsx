import person from "../assets/images/pirsonal deatels.png";
import work from "../assets/images/work.png";
import school from "../assets/images/study.png";
import warning from "../assets/images/dangeros.png";
import favorite from "../assets/images/health.png";
import home from "../assets/images/house.png";
import assignment from "../assets/images/antherneed.png";

export default function LeftSidebar() {
  const icons = [
    { label: "المعلومات الشخصية", image: person },
    { label: "مستندات الموارد", image: school },
    { label: "عمل أفراد الأسرة", image: work },
    { label: "المسكن", image: home },
    { label: "الحالة الصحية", image: favorite },
    { label: "تنبيهات السلامة", image: warning },
    { label: "أدوات ذكاء", image: assignment },
  ];

  const handleImageError = (e, label) => {
    console.error(`Failed to load image for ${label}: ${e.target.src}`);
    e.target.style.display = "none"; // Hide the broken image
    e.target.alt = `Failed to load ${label}`; // Update alt text for debugging
  };

  return (
    <div className="w-[90.133px] h-[754px] bg-[#D8FFF6] p-6 flex flex-col items-end  rounded-tr-none rounded-br-none rounded-bl-none shadow-[-7px_4px_4px_0px_rgba(0,0,0,0.25)] flex-shrink-0">
      <div className="space-y-4 w-full">
        {icons.map(({ label, image }, index) => (
          <div key={index} className="flex flex-col items-center w-full">
            <div className="w-[40px] h-[40px] rounded-full flex items-center justify-center bg-white overflow-hidden">
              <img
                src={image}
                alt={label}
                className="w-[25px] h-[25px] object-contain"
                onError={(e) => handleImageError(e, label)}
              />
            </div>
            <p className="text-[9px] font-medium text-[#1A1F33] text-center mt-1">{label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}