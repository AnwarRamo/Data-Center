// components/InputField.jsx
export default function InputField({ label, placeholder, type = "text", className = "" }) {
  return (
    <div className={`mb-4 ${className}`}>
      <label className="block text-sm font-medium text-[#1A1F33] mb-1">
        {label}
      </label>
      <input
        type={type}
        placeholder={placeholder}
        className="w-full px-4 py-2 border border-gray-200 rounded-xl bg-white focus:ring-2 focus:ring-[#1A1F33] focus:border-transparent"
      />
    </div>
  );
}