import React from 'react';
import InputField from '../components/InputField';

const PersonalInfoPage = () => {
  return (
    <div className="flex h-screen font-sans">
      
      {/* Right Sidebar */}
      <aside className="w-[20%] bg-[#D9F8F4] p-4 flex flex-col items-center rounded-l-3xl shadow-md">
        <div className="mb-6 text-xl font-semibold">اسم رب العائلة</div>
        <div className="w-full space-y-4">
          <button className="bg-white rounded-full px-4 py-2 w-full shadow">اسم الزوجة</button>
          <button className="bg-white rounded-full px-4 py-2 w-full shadow">اسم الابن الأول</button>
          <button className="bg-white rounded-full px-4 py-2 w-full shadow">اسم الابن الثاني</button>
          <button className="bg-white rounded-full px-4 py-2 w-full shadow">اسم الابن الثالث</button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 bg-[#E4E9EF] p-10 overflow-auto">
        <h1 className="text-2xl font-bold text-center mb-10">المعلومات الشخصية</h1>

        <div className="grid grid-cols-2 gap-6 max-w-4xl mx-auto">
          <InputField placeholder="الاسم الأول" />
          <InputField placeholder="الكنية" />
          <InputField placeholder="اسم الأب" />
          <InputField placeholder="اسم الأم" />
          <InputField placeholder="الجنس" />
          <InputField placeholder="الرقم الوطني" />
          <InputField placeholder="تاريخ الميلاد" />
          <InputField placeholder="رقم الهاتف" />
          <InputField placeholder="رقم الموبايل" />
          <InputField placeholder="صفة القرابة" />
        </div>

        <div className="flex justify-center gap-4 mt-10">
          <button className="bg-[#8C82FC] text-white px-6 py-2 rounded-full">تعديل</button>
          <button className="bg-[#B9B7F7] text-black px-6 py-2 rounded-full">رجوع</button>
        </div>
      </main>
    </div>
  );
};

export default PersonalInfoPage;
