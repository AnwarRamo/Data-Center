// pages/Housing.jsx
export default function Housing() {
  return (
    <div className="flex-grow p-8 pr-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-[#1A1F33]">المسكن</h1>
        {/* Same button group */}
      </div>

      <FormSection title="معلومات السكن">
        <RadioGroup
          label="ملكية المنزل"
          options={['ملك', 'إيجار', 'رهن', 'غير ذلك']}
        />
        <RadioGroup
          label="هل تملك سيارة"
          options={['نعم', 'لا']}
        />
      </FormSection>

      <FormSection title="العنوان التفصيلي">
        <div className="grid grid-cols-2 gap-4">
          <InputField label="المحافظة" />
          <InputField label="الحي" />
          <InputField label="الشارع" />
          <InputField label="رقم المنزل" />
        </div>
      </FormSection>
    </div>
  );
}