import { useState } from "react";
import LeftSidebar from "../components/LeftSidebar";
import Sidebar from "../components/Sidebar";
import InputField from "../components/InputField";

export default function ProfilePage() {
  const [members, setMembers] = useState([
    "اسم الزوجة",
    "اسم الولدالاول",
    "اسم الولد الثاني",
    "اسم الولد الثالث",
  ]);

  const addMember = () => setMembers([...members, "اسم فرد جديد"]);
  const removeMember = () => {
    if (members.length > 0) setMembers(members.slice(0, -1));
  };

  return (
    <div className="flex w-full h-screen font-sans text-right bg-[#E0E5EB] overflow-hidden">
      {/* Left Sidebar */}
      <LeftSidebar addMember={addMember} removeMember={removeMember} />

      {/* Main Content */}
      <div className="flex-grow p-10">
        {/* Title positioned top-right with slight offset from center */}
        <h1
          className="text-2xl font-bold mb-8 text-[#1A1F33] text-right"
          style={{ marginRight: "15%" }}
        >
          المعلومات الشخصية
        </h1>

        {/* Form container as two-column layout */}
        <div className="grid grid-cols-2 gap-x-6 gap-y-4 pr-[10%] pt-6">
          <div>
            <label className="block text-xs font-medium text-[#1A1F33] text-right mb-1">
              الاسم الأول
            </label>
            <InputField
              placeholder="الاسم الأول"
              className="w-full text-right text-sm py-1 px-2"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#1A1F33] text-right mb-1">
              الكنية
            </label>
            <InputField
              placeholder="الكنية"
              className="w-full text-right text-sm py-1 px-2"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#1A1F33] text-right mb-1">
              اسم الأب
            </label>
            <InputField
              placeholder="اسم الأب"
              className="w-full text-right text-sm py-1 px-2"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#1A1F33] text-right mb-1">
              اسم الأم
            </label>
            <InputField
              placeholder="اسم الأم"
              className="w-full text-right text-sm py-1 px-2"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#1A1F33] text-right mb-1">
              الجنس
            </label>
            <InputField
              placeholder="الجنس"
              className="w-full text-right text-sm py-1 px-2"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#1A1F33] text-right mb-1">
              الرقم الوطني
            </label>
            <InputField
              placeholder="الرقم الوطني"
              className="w-full text-right text-sm py-1 px-2"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#1A1F33] text-right mb-1">
              تاريخ الميلاد
            </label>
            <InputField
              placeholder="تاريخ الميلاد"
              className="w-full text-right text-sm py-1 px-2"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#1A1F33] text-right mb-1">
              رقم الهاتف
            </label>
            <InputField
              placeholder="رقم الهاتف"
              className="w-full text-right text-sm py-1 px-2"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#1A1F33] text-right mb-1">
              رقم الموبايل
            </label>
            <InputField
              placeholder="رقم الموبايل"
              className="w-full text-right text-sm py-1 px-2"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#1A1F33] text-right mb-1">
              صفة القرابة
            </label>
            <InputField
              placeholder="صفة القرابة"
              className="w-full text-right text-sm py-1 px-2"
            />
          </div>
        </div>

        {/* Buttons positioned left-bottom with slight offset */}
        <div
          className="flex gap-4 mt-8"
          style={{ justifyContent: "flex-start", marginLeft: "10px" }}
        >
          <button className="px-5 py-2 bg-[#4A90E2] text-white font-medium rounded-lg shadow-[0_4px_8px_rgba(0,0,0,0.25)] hover:bg-opacity-90">
            جوع
          </button>
          <button className="px-5 py-2 bg-[#9B59B6] text-white font-medium rounded-lg shadow-[0_4px_8px_rgba(0,0,0,0.25)] hover:bg-opacity-90">
            تعديل
          </button>
        </div>
      </div>

      {/* Right Sidebar */}
      <Sidebar
        members={members}
        addMember={addMember}
        removeMember={removeMember}
      />
    </div>
  );
}
