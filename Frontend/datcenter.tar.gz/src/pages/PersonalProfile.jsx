import { useState } from "react";
import Sidebar from "../components/Sidebar";
import person from "../assets/images/pirsonal deatels.png";
import work from "../assets/images/work.png";
import school from "../assets/images/study.png";
import warning from "../assets/images/dangeros.png";
import favorite from "../assets/images/health.png";
import home from "../assets/images/house.png";
import assignment from "../assets/images/antherneed.png";

export default function PersonalProfile() {
  const [members, setMembers] = useState([
    "اسم الزوجة",
    "اسم الولدالاول",
    "اسم الولد الثاني",
    "اسم الولد الثالث",
  ]);

  const addMember = () => setMembers([...members, "اسم فرد جديد"]);
  const removeMember = () => {
    if (members.length > 0) setMembers(members.slice(0, -1));
  };

  const icons = [
    { label: "المعلومات الشخصية", image: person },
    { label: "عمل أفراد الأسرة", image: work },
    { label: "مستوى الدراسة", image: school },
    { label: "التأثر بأزمة", image: warning },
    { label: "الحالة الصحية", image: favorite },
    { label: "المسكن", image: home },
    { label: "احتياجات أخرى", image: assignment },
  ];

  return (
    <div className="flex w-full h-screen font-sans text-right bg-[#E0E5EB] overflow-hidden">
      <div className="flex flex-row-reverse w-full">
        <Sidebar
          members={members}
          addMember={addMember}
          removeMember={removeMember}
        />

        {/* Main Content */}
        <div className="flex-grow p-10 pr-14">
          <h1 className="text-2xl font-bold mb-8 text-[#1A1F33]">الملف الشخصي</h1>
          <div className="grid grid-cols-3 gap-6">
            {icons.map(({ label, image }, index) => (
              <div
                key={index}
                className={`flex flex-col items-center text-[#1A1F33] ${
                  label === "احتياجات أخرى" ? "col-span-3" : ""
                }`}
              >
                <div className="w-20 h-20 bg-[#DCFFF7] rounded-2xl flex items-center justify-center shadow-md mb-2">
                  <img src={image} alt={label} className="w-[50px] h-[50px]" />
                </div>
                <p className="text-sm font-medium text-center">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}