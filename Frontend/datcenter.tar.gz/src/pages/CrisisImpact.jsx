// pages/CrisisImpact.jsx
import { Link } from 'react-router-dom';
import { FormSection, RadioGroup, InputField } from '../components';

export default function CrisisImpact() {
  return (
    <div className="flex-grow p-8 pr-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-[#1A1F33]">التأثر بأزمة</h1>
        <div className="flex gap-4">
          <Link to="/" className="bg-[#DCFFF7] px-6 py-2 rounded-2xl text-[#1A1F33] font-medium">
            رجوع
          </Link>
          <button className="bg-[#1A1F33] px-6 py-2 rounded-2xl text-white font-medium">
            تعديل
          </button>
        </div>
      </div>

      <FormSection title="طبيعة التأثر">
        <RadioGroup
          options={[
            "ضرح طبيعة التأثر",
            "تصريح الحاجة للمساعدة",
            "لست بحاجة للمساعدة"
          ]}
        />
      </FormSection>

      <FormSection title="الاحتياجات">
        <InputField label="الاحتياج الأول" />
        <InputField label="الاحتياج الثاني" />
        <InputField label="الاحتياج الثالث" />
      </FormSection>
    </div>
  );
}