export default function Health() {
  return (
    <div className="flex-grow p-8 pr-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-[#1A1F33]">حالة الصحية</h1>
        {/* Same button group as previous */}
      </div>

      <FormSection title="المعلومات الشخصية">
        <RadioGroup
          label="الحالة الصحية"
          options={['ميزان متونين', 'ريالية كبار سن', 'ذوي احتياجات خاصة']}
        />
      </FormSection>

      <FormSection title="تفاصيل إضافية">
        <div className="grid grid-cols-2 gap-4">
          <InputField label="اسم رب العائلة" />
          <InputField label="اسم الزوجة" />
          <InputField label="اسم الدين الأول" />
          <InputField label="اسم الدين الثاني" />
        </div>
      </FormSection>
    </div>
  );
}